# te_ventas
## se modifico
el archivo VentaControlador estaba fuera de la carpeta de los controladores, asi que hize el segundo commit para cambiarlo al directorio correcto
